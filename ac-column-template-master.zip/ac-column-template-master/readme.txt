=== Admin Columns - COLUMN_LABEL Column ===
Contributors: AUTHOR_NAME
Tags: PLUGIN_TAGS
Requires at least: 3.5
Tested up to: 4.1
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

DESCRIPTION

== Description ==

EXTENDED_DESCRIPTION

== Installation ==

1. Copy the `ac-column-COLUMN_NAME` folder into your `wp-content/plugins` folder
2. Activate the COLUMN_LABEL plugin via the plugins admin page
3. Create a new column via Admin Columns and select the COLUMN_LABEL column
4. Please refer to the description for more info regarding the field type settings

== Changelog ==

= 1.0 =
* Initial Release.